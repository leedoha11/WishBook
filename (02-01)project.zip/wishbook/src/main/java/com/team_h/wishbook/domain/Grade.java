package com.team_h.wishbook.domain;
import lombok.Data;

@Data
public class Grade {
	private int gradeId;
	private String name;
	private int pointRate;
	private int standardPrice;
}
